package com.fizz;

import java.util.ArrayList;

/**
 * Created by bruno on 27/07/16.
 */
public class FizzBuzzResult {
    private ArrayList<String> result;
    private int fizzCount;
    private int buzzCount;
    private int fizzBuzzCount;
    private int luckyCount;

    public ArrayList<String> getResult() {
        return result;
    }

    public void setResult(ArrayList<String> result) {
        this.result = result;
    }

    public int getFizzCount() {
        return fizzCount;
    }

    public void setFizzCount(int fizzCount) {
        this.fizzCount = fizzCount;
    }

    public int getBuzzCount() {
        return buzzCount;
    }

    public void setBuzzCount(int buzzCount) {
        this.buzzCount = buzzCount;
    }

    public int getFizzBuzzCount() {
        return fizzBuzzCount;
    }

    public void setFizzBuzzCount(int fizzBuzzCount) {
        this.fizzBuzzCount = fizzBuzzCount;
    }

    public int getLuckyCount() {
        return luckyCount;
    }

    public void setLuckyCount(int luckyCount) {
        this.luckyCount = luckyCount;
    }

    public FizzBuzzResult incrementFizzCount() {
        ++fizzCount;
        return this;
    }

    public FizzBuzzResult incrementBuzzCount() {
        ++buzzCount;
        return this;
    }

    public FizzBuzzResult incrementFizzBuzzCount() {
        ++fizzBuzzCount;
        return this;
    }

    public FizzBuzzResult incrementLuckyCount() {
        ++luckyCount;
        return this;
    }

    public String resultsToString() {
        return String.join(" ", result);
    }

    @Override
    public String toString() {
        return resultsToString() + "\n" +
                "fizz: " + fizzCount  + "\n" +
                "buzz: " + buzzCount  + "\n" +
                "fizzbuzz: " + fizzBuzzCount + "\n" +
                "lucky: " + luckyCount;

    }
}
