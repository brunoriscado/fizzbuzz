package com.fizz;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bruno on 26/07/16.
 */
public class FizzBuzzProcessor {
    private static final String FIZZ = "fizz";
    private static final String BUZZ = "buzz";
    private static final String LUCKY = "lucky";

    public FizzBuzzResult processFizzBuzz(int start, int end) {
        FizzBuzzResult result = null;
        if (start <= end) {
            result = new FizzBuzzResult();
            result.setResult(new ArrayList<String>());
            for (; start <= end; start++) {
                calculateFizzBuzzForNumber(start, result);
            }
        } else {
            throw new RuntimeException("Oooops, incorrect range - start: " + start + " - end: " + end);
        }
        return result;
    }

    private void calculateFizzBuzzForNumber(int number, FizzBuzzResult fizzBuzzResult) {
        String result = String.valueOf(number);
        if (result.contains("3")) {
            result = LUCKY;
            fizzBuzzResult.incrementLuckyCount();
        } else if (number % 3 == 0 && number % 5 == 0) {
            result = FIZZ + BUZZ;
            fizzBuzzResult.incrementFizzBuzzCount();
        } else if (number % 3 == 0) {
            result = FIZZ;
            fizzBuzzResult.incrementFizzCount();
        } else if (number % 5 == 0) {
            result = BUZZ;
            fizzBuzzResult.incrementBuzzCount();
        }
        fizzBuzzResult.getResult().add(result);
    }
}
