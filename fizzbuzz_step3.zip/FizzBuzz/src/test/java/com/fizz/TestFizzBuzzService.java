package com.fizz;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mockito;

import java.util.Arrays;

/**
 * Created by bruno on 26/07/16.
 */
@RunWith(JUnit4.class)
public class TestFizzBuzzService {
    private FizzBuzzProcessor fizzBuzzProcessor;

    @Before
    public void setup() {
        fizzBuzzProcessor = Mockito.spy(FizzBuzzProcessor.class);
    }

    @Test
    public void testResponseWithRegularRange() {
        int start = 1;
        int end = 20;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(Arrays.asList("1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz 16 17 fizz 19 buzz".split(" ")),
                result.getResult());
        Assert.assertEquals("fizz count", 4, result.getFizzCount());
        Assert.assertEquals("buzz count", 3, result.getBuzzCount());
        Assert.assertEquals("fizzbuzz count", 1, result.getFizzBuzzCount());
        Assert.assertEquals("lucky count", 2, result.getLuckyCount());
    }

    @Test
    public void testResponseWithNegativeRangeAndZero() {
        int start = -5;
        int end = 15;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(Arrays.asList("buzz -4 lucky -2 -1 fizzbuzz 1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz".split(" ")),
                result.getResult());
        Assert.assertEquals("fizz count", 3, result.getFizzCount());
        Assert.assertEquals("buzz count", 3, result.getBuzzCount());
        Assert.assertEquals("fizzbuzz count", 2, result.getFizzBuzzCount());
        Assert.assertEquals("lucky count", 3, result.getLuckyCount());
    }

    @Test
    public void testResponseWithNoRangeAllNumeric() {
        int start = 1;
        int end = 1;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(Arrays.asList("1".split(" ")),
                result.getResult());
        Assert.assertEquals("fizz count", 0, result.getFizzCount());
        Assert.assertEquals("buzz count", 0, result.getBuzzCount());
        Assert.assertEquals("fizzbuzz count", 0, result.getFizzBuzzCount());
        Assert.assertEquals("lucky count", 0, result.getLuckyCount());
    }

    @Test
    public void testResponseWithNoRangeAllFizzes() {
        int start = 6;
        int end = 6;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(Arrays.asList("fizz".split(" ")),
                result.getResult());
        Assert.assertEquals("fizz count", 1, result.getFizzCount());
        Assert.assertEquals("buzz count", 0, result.getBuzzCount());
        Assert.assertEquals("fizzbuzz count", 0, result.getFizzBuzzCount());
        Assert.assertEquals("lucky count", 0, result.getLuckyCount());
    }

    @Test
    public void testResponseWithNoRangeAllBuzzes() {
        int start = 10;
        int end = 10;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(Arrays.asList("buzz".split(" ")),
                result.getResult());
        Assert.assertEquals("fizz count", 0, result.getFizzCount());
        Assert.assertEquals("buzz count", 1, result.getBuzzCount());
        Assert.assertEquals("fizzbuzz count", 0, result.getFizzBuzzCount());
        Assert.assertEquals("lucky count", 0, result.getLuckyCount());
    }

    @Test
    public void testResponseWithNoRangeAllFizzBuzz() {
        int start = 15;
        int end = 15;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(Arrays.asList("fizzbuzz".split(" ")),
                result.getResult());
        Assert.assertEquals("fizz count", 0, result.getFizzCount());
        Assert.assertEquals("buzz count", 0, result.getBuzzCount());
        Assert.assertEquals("fizzbuzz count", 1, result.getFizzBuzzCount());
        Assert.assertEquals("lucky count", 0, result.getLuckyCount());
    }

    @Test
    public void testEndValueLowerThanStartValue() {
        int start = 1;
        int end = -1;
        try {
            fizzBuzzProcessor.processFizzBuzz(start, end);
        } catch (RuntimeException e) {
            return;
        }
        Assert.fail("Should have thrown an exception, due to incorrect range");
    }

    @Test
    public void testResponseAllLucky() {
        int start = 30;
        int end = 39;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(Arrays.asList("lucky lucky lucky lucky lucky lucky lucky lucky lucky lucky".split(" ")),
                result.getResult());
        Assert.assertEquals("fizz count", 0, result.getFizzCount());
        Assert.assertEquals("buzz count", 0, result.getBuzzCount());
        Assert.assertEquals("fizzbuzz count", 0, result.getFizzBuzzCount());
        Assert.assertEquals("lucky count", 10, result.getLuckyCount());
    }

    @Test
    public void testResponseWithNoRangeAllLucky() {
        int start = 3333;
        int end = 3333;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(Arrays.asList("lucky".split(" ")),
                result.getResult());
        Assert.assertEquals("fizz count", 0, result.getFizzCount());
        Assert.assertEquals("buzz count", 0, result.getBuzzCount());
        Assert.assertEquals("fizzbuzz count", 0, result.getFizzBuzzCount());
        Assert.assertEquals("lucky count", 1, result.getLuckyCount());
    }

    @Test
    public void testNoLucky() {
        int start = -2;
        int end = 2;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(Arrays.asList("-2 -1 fizzbuzz 1 2".split(" ")),
                result.getResult());
        Assert.assertEquals("fizz count", 0, result.getFizzCount());
        Assert.assertEquals("buzz count", 0, result.getBuzzCount());
        Assert.assertEquals("fizzbuzz count", 1, result.getFizzBuzzCount());
        Assert.assertEquals("lucky count", 0, result.getLuckyCount());
    }

    @Test
    public void testReportOutputForRegularRange() {
        int start = 1;
        int end = 20;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(
                "1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz 16 17 fizz 19 buzz\n" +
                "fizz: 4\n" +
                "buzz: 3\n" +
                "fizzbuzz: 1\n" +
                "lucky: 2",
                result.toString());
    }

    @Test
    public void testReportOutputWithNegativeRangeAndZero() {
        int start = -5;
        int end = 15;
        FizzBuzzResult result = fizzBuzzProcessor.processFizzBuzz(start, end);
        Assert.assertEquals(
                "buzz -4 lucky -2 -1 fizzbuzz 1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz\n" +
                "fizz: 3\n" +
                "buzz: 3\n" +
                "fizzbuzz: 2\n" +
                "lucky: 3",
                result.toString());
    }
 }
