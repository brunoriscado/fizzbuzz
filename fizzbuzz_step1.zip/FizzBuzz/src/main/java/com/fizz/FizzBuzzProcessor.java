package com.fizz;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bruno on 26/07/16.
 */
public class FizzBuzzProcessor {
    private static final String FIZZ = "fizz";
    private static final String BUZZ = "buzz";

    public List<String> processFizzBuzzRange(int start, int end) {
        List<String> result = null;
        if (start <= end) {
            result = new ArrayList<String>();
            for (; start <= end; start++) {
                result.add(calculateFizzBuzzForNumber(start));
            }
        } else {
            throw new RuntimeException("Oooops, incorrect range - start: " + start + " - end: " + end);
        }
        return result;
    }

    private String calculateFizzBuzzForNumber(int number) {
        String result = null;
        if (number % 3 == 0 && number % 5 == 0) {
            result = FIZZ + BUZZ;
        } else if (number % 3 == 0) {
            result = FIZZ;
        } else if (number % 5 == 0) {
            result = BUZZ;
        } else {
            result = String.valueOf(number);
        }
        return result;
    }
}
